# IMAGES
#========================================================
image bgnotebook = "UserInterface/Notebook.png"


# NOTEBOOK PAGE TRACKING
# =========================================================
# This keeps track of which page the player is viewing.
default notebook_page = 0

# Total number of pages minus 1
# If there are 2 pages, the max page index is 1.
default notebook_max_page = 9


# =========================================================
# NOTEBOOK SCREEN
# =========================================================
screen notebook_screen():

    tag notebook
    modal True

    # Dark transparent overlay behind the notebook
    add Solid("#0008")

    # Main notebook window
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1400
        ysize 800

        # Remove frame background
        background None

        # Remove default margins
        padding (0,0)

        add "bgnotebook"

        # -------------------------------------------------
        # MAIN LAYOUT
        # -------------------------------------------------
        # We use an hbox to split the notebook into two sections:
        # 1. Left side for portrait
        # 2. Right side for notes
        hbox:
            spacing 40
            xpos 40
            ypos 40

            # =================================================
            # LEFT SIDE: CHARACTER PORTRAIT
            # =================================================
            frame:
                xsize 310
                ysize 260
                xpos 190 - 45
                ypos 120 - 35

                # Remove frame background
                background None

                # Remove default margins
                padding (0,0)

                # Show a different portrait depending on the current page
                if notebook_page == 3:
                    add anna_facts['portrait']:
                        xalign 0.5
                        yalign 0.5
                    if anna_facts['marked'] == True:
                        add "notebookdead":
                            xalign 0.17
                            yalign 0.25
                            
                            
                            
              
                elif notebook_page == 2:
                    add sarah_facts['portrait']:
                        xalign 0.5
                        yalign 0.5
                    if sarah_facts['marked'] == True:
                        add "notebookdead":
                            xalign 0.17
                            yalign 0.25
                
                elif notebook_page == 4:
                    add rick_facts['portrait']:
                        xalign 0.5
                        yalign 0.5
                    if rick_facts['marked'] == True:
                        add "notebookdead":
                            xalign 0.17
                            yalign 0.25
                
                elif notebook_page == 5:
                    add lydia_facts['portrait']:
                        xalign 0.5
                        yalign 0.5
                    if lydia_facts['marked'] == True:
                        add "notebookdead":
                            xalign 0.17
                            yalign 0.25

                elif notebook_page == 6:
                    add orion_facts['portrait']:
                        xalign 0.5
                        yalign 0.5
                    if orion_facts['marked'] == True:
                        add "notebookdead":
                            xalign 0.17
                            yalign 0.25

                elif notebook_page == 7:
                    add aster_facts['portrait']:
                        xalign 0.5
                        yalign 0.5
                    if aster_facts['marked'] == True:
                        add "notebookdead":
                            xalign 0.17
                            yalign 0.25

                elif notebook_page == 8:
                    add violet_facts['portrait']:
                        xalign 0.5
                        yalign 0.5
                    if violet_facts['marked'] == True:
                        add "notebookdead":
                            xalign 0.17
                            yalign 0.25

                elif notebook_page == 9:
                    add martin_facts['portrait']:
                        xalign 0.5
                        yalign 0.5
                    if martin_facts['marked'] == True:
                        add "notebookdead":
                            xalign 0.17
                            yalign 0.25
            # =================================================
            # RIGHT SIDE: CHARACTER NOTES
            # =================================================
            frame:
                xsize 750
                ysize 650
                xpos 550 - 350
                ypos 90 - 80

                # Remove frame background
                background None

                # Remove default margins
                padding (0,0)

                vbox:
                    spacing 20
                    xpos 30   
                    ypos 30

                    # Show different notes depending on the current page
                   
                    
                    if notebook_page == 3:

                        text anna_facts['name'] size 42
                        text "Notes:" size 30

                        text "* [anna_facts['fact1']]"
                        
                        

                    elif notebook_page == 2:

                        text sarah_facts['name'] size 42
                        text "Notes:" size 30

                        text "* [sarah_facts['fact1']]"
                        
                    elif notebook_page == 4:

                        text rick_facts['name'] size 42
                        text "Notes:" size 30

                        text "* [rick_facts['fact1']]"
                        
                    elif notebook_page == 5:

                        text lydia_facts['name'] size 42
                        text "Notes:" size 30

                        text "* [lydia_facts['fact1']]"
                       

                    elif notebook_page == 6:

                        text orion_facts['name'] size 42
                        text "Notes:" size 30

                        text "* [orion_facts['fact1']]"
                      

                    elif notebook_page == 7:

                        text aster_facts['name'] size 42
                        text "Notes:" size 30

                        text "* [aster_facts['fact1']]"

                    elif notebook_page == 8:

                        text violet_facts['name'] size 42
                        text "Notes:" size 30

                        text "* [violet_facts['fact1']]"

                    elif notebook_page == 9:

                        text martin_facts['name'] size 42
                        text "Notes:" size 30

                        text "* [martin_facts['fact1']]"
                       
                    elif notebook_page == 0:

                        text "Player Stats" size 42
                        text "Current Status" size 30

                        text "Trust" size 28

                        bar:
                            value trust
                            range max_trust
                            xmaximum 500
                            ymaximum 30
                        
                        

                        text "[trust] / [max_trust]" size 22

                        null height 30

                        text "Oxygen" size 28

                        bar:
                            value oxygen
                            range max_oxygen
                            xmaximum 500
                            ymaximum 30

                        text "[oxygen] / [max_oxygen]" size 22

                    elif notebook_page == 1:
                        text "Contamination Level" size 28

                        bar: 
                            value contamination_level
                            range max_contamination_level
                            xmaximum 500
                            ymaximum 30

                        text "Filter Level [filter_level]" size 28
                            
                        bar:
                            value filter_level
                            range max_filter_level
                            xmaximum 500
                            ymaximum 30

                        hbox:
                            spacing 20
                            textbutton "-":
                                action SetVariable("filter_level", max(1, filter_level - 1))

                            textbutton "+":
                                action SetVariable("filter_level", min(max_filter_level, filter_level +1))
        # -------------------------------------------------
        # PAGE NUMBER
        # -------------------------------------------------
        text "Page [notebook_page + 1] / [notebook_max_page + 1]":
            xalign 0.5
            yalign 0.93

        # -------------------------------------------------
        # PREVIOUS BUTTON
        # -------------------------------------------------
        if notebook_page > 0:
            textbutton "Previous":
                xpos 60
                ypos 730
                text_idle_color "#9DA9C2" # Color when not hovered
                text_hover_color "#404752" # Color when hovered
                action SetVariable("notebook_page", notebook_page - 1)

        # -------------------------------------------------
        # NEXT BUTTON
        # -------------------------------------------------
        if notebook_page < notebook_max_page:
            textbutton "Next":
                xpos 1240
                ypos 730
                text_idle_color "#9DA9C2" # Color when not hovered
                text_hover_color "#404752" # Color when hovered
                action SetVariable("notebook_page", notebook_page + 1)

    # Press N to close notebook
    key "n" action Hide("notebook_screen")


# =========================================================
# NOTEBOOK KEY LISTENER
# =========================================================
# This lets the player press N at any time to open/close
# the notebook.
screen notebook_key_listener():
    key "n" action [SetVariable("notebook_page", 0), ToggleScreen("notebook_screen")]


# =========================================================
# REGISTER THE KEY LISTENER
# =========================================================
init python:
    if "notebook_key_listener" not in config.overlay_screens:
        config.overlay_screens.append("notebook_key_listener")